import { Injectable } from '@angular/core';
import { Insta } from './insta';
import { HttpClient } from '@angular/common/http';
//import 'rxjs/add/operator/toPromise';

@Injectable()	
export class InstaService {
  private baseUrl = 'http://localhost:10005';	

  constructor(private http: HttpClient) { }

  getInsta():  Promise<Insta[]> {	
    return this.http.get(this.baseUrl + '/api/instaUsers/')	
      .toPromise()	
      .then(response => response as Insta[])	
      .catch(this.handleError);
  }

  createInsta(insta: Insta): Promise<Insta> {
    return this.http.post(this.baseUrl + '/api/instaUsers/', insta)
      .toPromise().then(response => response as Insta)
      .catch(this.handleError);
  }

  deleteInsta(email: string): Promise<any> {
    return this.http.delete(this.baseUrl + '/api/instaUsers/' + email)
      .toPromise()
      .catch(this.handleError);
  }

  updateInsta(insta: Insta): Promise<Insta> {

    return this.http.put(this.baseUrl+'/api/instaUsers/'+insta.email,insta)
    .toPromise()
    .then(response => response as Insta)
    .catch(this.handleError);
  }
  private handleError(error: any): Promise<any> {
    console.error('Some error occured', error);
    return Promise.reject(error.message || error);
  }
}