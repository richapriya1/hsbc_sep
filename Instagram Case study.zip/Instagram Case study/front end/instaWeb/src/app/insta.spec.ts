import { Insta } from './insta';

describe('Insta', () => {
  it('should create an instance', () => {
    expect(new Insta()).toBeTruthy();
  });
});
