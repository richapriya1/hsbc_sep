export class Insta {
    name:string;
    password:string;
    email:string;
    address:string;
}
