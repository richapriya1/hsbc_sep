import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule }    from '@angular/common/http';
import { FormsModule }   from '@angular/forms';

import { AppComponent } from './app.component';
import { InstaComponent } from './insta.component';
import { InstaService } from './insta.service';

@NgModule({
  declarations: [
    AppComponent,InstaComponent
  ],
  imports: [
    BrowserModule, HttpClientModule, FormsModule
  ],
  providers: [InstaService],
  bootstrap: [AppComponent]
})
export class AppModule { }
