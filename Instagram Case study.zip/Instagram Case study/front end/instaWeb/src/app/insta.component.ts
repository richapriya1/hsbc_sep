import { Component, Input, OnInit } from '@angular/core';
import { InstaService } from './insta.service';
import { Insta } from './insta';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'insta',
  templateUrl: 'insta.component.html'
})

export class InstaComponent implements OnInit {
	insta: Insta[];
  newInsta: Insta = new Insta();
  editing: boolean = false;
  editingInsta: Insta = new Insta();

	constructor(
	  private instaService: InstaService,
	) {}

	ngOnInit(): void {		
		this.getInsta();
  }

  getInsta(): void {
    this.instaService.getInsta()	
      .then(insta => this.insta = insta );  	
  }

  createInsta(instaForm: NgForm): void {
    this.instaService.createInsta(this.newInsta)
      .then(createInsta => {        
        //instaForm.reset();
	      this.newInsta = new Insta();
	      this.insta.unshift(this.newInsta);
      });
  }

  deleteInsta(email: string): void {
  	this.instaService.deleteInsta(email)
  	.then(() => {
  		this.insta = this.insta.filter(user => user.email != email);
  	});
  }

  editInsta(insta:Insta): void{
    this.editing =true;
    //console.log(insta.name);
    Object.assign(this.editingInsta,insta);
  }

  updateInsta(insta:Insta):void{
    console.log(insta);
    //console.log(insta.email);
    this.instaService.updateInsta(insta)
    .then(updatedInsta=> {
        let existingInsta =this.insta.find(user=>user.email === updatedInsta.email);
        Object.assign(existingInsta,updatedInsta);
        this.clearEditing();
      });
  }
  clearEditing(): void{
    this.editingInsta=new Insta();
    this.editing=false;
  }
}