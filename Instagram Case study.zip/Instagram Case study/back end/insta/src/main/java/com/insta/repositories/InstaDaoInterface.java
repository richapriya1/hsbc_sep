package com.insta.repositories;

import java.util.List;

import com.insta.model.Insta;

public interface InstaDaoInterface {

	List<Insta> createprofile(Insta fe);

	List<Insta> getAllUsers();

	//void delete(String email);

	Insta updateInstaUser(Insta iu) throws Exception;

	int delete(String email);

}
