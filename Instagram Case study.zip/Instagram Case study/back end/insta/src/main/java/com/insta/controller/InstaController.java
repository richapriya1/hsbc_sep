package com.insta.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.insta.model.Insta;
import com.insta.repositories.InstaDao;
import com.insta.repositories.InstaDaoInterface;


@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class InstaController {

	@Autowired
	private InstaDaoInterface d;
	
	@GetMapping("/instaUsers")
	
	public List<Insta> getAllUsers() throws Exception{
		List<Insta> l=d.getAllUsers();
		
		return l;
	}
	
	@PostMapping("/instaUsers")
	public List<Insta> createProfile(@RequestBody Insta i){
		
		List<Insta> i2=d.createprofile(i);
		System.out.println("created");
		return i2;
	}
	
	 @DeleteMapping(value="/instaUsers/{email}")
	    public void deleteTodo(@PathVariable("email") String email) {
		 //Insta iu=new Insta();
			//iu.setEmail(email);
			
			int x=d.delete(email);
			if(x>0) {
				System.out.println("Profile deleted");
			}
			else {
				System.out.println("No record found");
			}
		 
	    }
	 
	 @PutMapping("/instaUsers/{email}")
		public ResponseEntity<Insta> updateUser(@PathVariable("email") String email,@RequestBody Insta iu) throws Exception{
			
			iu.setEmail(email);
			Insta iu1=d.updateInstaUser(iu);
			if(iu1==null) {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
			else {
				return new ResponseEntity<>(iu1,HttpStatus.OK);
			}
		}
}
