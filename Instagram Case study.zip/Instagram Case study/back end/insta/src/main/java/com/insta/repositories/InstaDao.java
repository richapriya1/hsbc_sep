package com.insta.repositories;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.insta.model.Insta;


@Repository
public class InstaDao implements InstaDaoInterface{

	private Connection con;
	public InstaDao() {
		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			con=DriverManager.getConnection("jdbc:derby:c:/firstdb1;create=true","richa","priya");
		}
		
		catch(ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
	}
	@Override
	public List<Insta> createprofile(Insta iu){
		// TODO Auto-generated method stub
		List<Insta> ll=new ArrayList<Insta>();
		int i=0;
	
		try {
				PreparedStatement ps=con.prepareStatement("insert into instatable values(?,?,?,?)");
				ps.setString(1, iu.getName());
				ps.setString(2, iu.getPassword());
				ps.setString(3, iu.getEmail());
				ps.setString(4, iu.getAddress());
				ll.add(iu);
				//step 4 executeQuery
				i=ps.executeUpdate();
		}
		catch(SQLException ee) {
			ee.printStackTrace();
		}
				
					return ll;
	}
	@Override
	public List<Insta> getAllUsers(){
		
		List<Insta> ll=new ArrayList<Insta>();
		
		try {
			PreparedStatement ps=con.prepareStatement("select * from instatable");
			ResultSet res=ps.executeQuery();
			while(res.next()) {
				Insta uu=new Insta();
				uu.setName(res.getString(1));
				uu.setPassword(res.getString(2));
				uu.setEmail(res.getString(3));
				uu.setAddress(res.getString(4));
				
				ll.add(uu);
			}	
		}
			catch(SQLException ee) {
				ee.printStackTrace();
			}
		
	
			return ll;
}
	@Override
	public int delete(String email) {
		System.out.println(email);
		int res=0;
		//Connection con=null;
		try {
			
			PreparedStatement ps=con.prepareStatement("delete from instatable where email=?");
			//Insta uu=new Insta();
			ps.setString(1, email);
			
			res=ps.executeUpdate();
		
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
		
		return res;
		
	}
	@Override
	public Insta updateInstaUser(Insta iu) throws Exception {
		System.out.println("name and email are:"+iu.getName()+" "+iu.getEmail());
		
		PreparedStatement ps=con.prepareStatement("update instatable set name=?,password=?,address=? where email=?");
		System.out.println("in dao "+iu.getEmail()+" "+iu.getName()+" "+iu.getPassword()+" "+iu.getAddress());
		ps.setString(1, iu.getName());
		ps.setString(2, iu.getPassword());
		ps.setString(3, iu.getAddress());
		ps.setString(4, iu.getEmail());
		int i=ps.executeUpdate();
		if(i>0) {
			return iu;
		}
		else
			return null;
	
		
	}
}
